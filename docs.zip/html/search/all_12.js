var searchData=
[
  ['throwlogicerror',['throwLogicError',['../namespace_json.html#a985ba6c9956ff5f84a96ba1fb293490f',1,'Json']]],
  ['throwruntimeerror',['throwRuntimeError',['../namespace_json.html#a7062be11352221ab5886f13609f70b7e',1,'Json']]]
];
