var searchData=
[
  ['logicerror',['LogicError',['../class_json_1_1_logic_error.html',1,'Json']]]
];
