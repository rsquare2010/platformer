var searchData=
[
  ['enum',['Enum',['../struct_json_1_1_comment_style.html#a51fc08f3518fd81eba12f340d19a3d0c',1,'Json::CommentStyle']]]
];
