var searchData=
[
  ['decimalplaces',['decimalPlaces',['../namespace_json.html#af6e1447a3c43e3a62e11050dd0a11ce8a1a301acf8cab9cba6cb8dfad2f6f3719',1,'Json']]]
];
