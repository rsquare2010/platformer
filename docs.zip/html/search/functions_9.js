var searchData=
[
  ['jsoncpp_5fdeprecated',['JSONCPP_DEPRECATED',['../namespace_json.html#a677dd20047c0c6e4eb16c5f1b53f703c',1,'Json::JSONCPP_DEPRECATED(&quot;Use StreamWriter instead&quot;) JSON_API Writer'],['../namespace_json.html#a5b17bada99725c9660c8b7520ffc5dfe',1,'Json::JSONCPP_DEPRECATED(&quot;Use StreamWriterBuilder instead&quot;) JSON_API StyledStreamWriter']]],
  ['jump',['jump',['../class_character.html#a95cf7b5c50efcabc7e8731a5958b53ca',1,'Character']]],
  ['jumpandmovetoleft',['jumpAndMoveToLeft',['../class_character.html#a72ce34bc86d041ef84c0e223c869912f',1,'Character']]],
  ['jumpandmovetoright',['jumpAndMoveToRight',['../class_character.html#a5b84affdc258b65e34058c97cde6d708',1,'Character']]]
];
